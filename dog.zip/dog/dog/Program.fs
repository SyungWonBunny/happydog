﻿open System

type Dog(name: string, species: string, documents: string list, admissionDate: DateTime) =
    member val Name = name with get, set
    member val Species = species with get, set
    member val Documents = documents with get, set
    member val AdmissionDate = admissionDate with get, set
    member val AdoptionDate = DateTime.MinValue with get, set
    abstract member Hungry : unit -> int
    default this.Hungry() = 0

type Smallsize(name, species, documents, admissionDate) =
    inherit Dog(name, species, documents, admissionDate)
    override this.Hungry() = 2

type Midsize(name, species, documents, admissionDate) =
    inherit Dog(name, species, documents, admissionDate)
    override this.Hungry() = 4

type Largesize(name, species, documents, admissionDate) =
    inherit Dog(name, species, documents, admissionDate)
    override this.Hungry() = 6

type Human(name: string, phone: string, email: string) =
    member val Name = name with get, set
    member val Phone = phone with get, set
    member val Email = email with get, set
    member this.ApplyToShelter(shelter: Shelter) = shelter.Apply(this)

and Shelter(name: string, phone: string, email: string, location: string) =
    let mutable money = 100000
    let mutable monthlyExpense = 0
    let mutable foodQuantity = 0
    let employeeList = new System.Collections.Generic.List<Human>()
    let voluntaryList = new System.Collections.Generic.List<Human>()

    member val Name = name with get, set
    member val Phone = phone with get, set
    member val Email = email with get, set
    member val Location = location with get, set
    member val Dogs = new System.Collections.Generic.List<Dog>() with get

    member this.Species(species: string) =
        this.Dogs |> Seq.filter (fun k -> k.Species = species) |> Seq.toList

    member this.RemoveDog(dog: Dog) =
        this.Dogs.Remove(dog) |> ignore

    member this.AddDog(dog: Dog) =
        this.Dogs.Add(dog)

    member this.FoodDemand() =
        this.Dogs |> Seq.sumBy (fun (k: Dog) -> k.Hungry())

    member this.Expense() =
        let expense = this.FoodDemand() * 5000 + employeeList.Count * 10000
        money <- money - expense
        foodQuantity <- foodQuantity + this.FoodDemand()
        expense

    member this.FeedDogs() =
        if employeeList.Count = 0 then failwith "No employees!"
        else foodQuantity <- foodQuantity - this.FoodDemand()

    member this.Apply(human: Human) =
        employeeList.Add(human)

[<EntryPoint>]
let main argv =
    let shelter = Shelter("HappyDog", "06301234567", "happydog@gmail.com", "Érd, Tárnoki utca 4.")

    shelter.AddDog(Midsize("Buksi", "German Shepherd", ["documents"], DateTime.Now))
    shelter.AddDog(Largesize("Lejla", "Wolfdog", ["documents"], DateTime.Now))
    shelter.AddDog(Smallsize("Töki", "Chihuahua", ["documents"], DateTime.Now))
    shelter.AddDog(Midsize("Nala", "Border Collie", ["documents"], DateTime.Now))

    printfn "Shelter: 1\nDog: 2"
    let choice = Console.ReadLine() |> int
    match choice with
    | 1 ->
        printfn "%s\n%s\n%s\n%s" shelter.Name shelter.Phone shelter.Email shelter.Location
    | 2 ->
        for dog in shelter.Dogs do
            printfn "%s\n%s\n%A" dog.Name dog.Species dog.Documents
    | _ -> printfn "Unknown choice"

    0
